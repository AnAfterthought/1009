#include "Equipment.h"

void Equipment::equip(Hero* hero) {
}

void Equipment::unequip(Hero* hero) {
}