#include "Knight.h"

Knight::Knight(std::string name, int health, int attack, double protection, int speed, bool playerCharacter):Hero(name, health, attack, protection, speed, playerCharacter) {

}

void Knight::strike(std::vector<Hero*>& party) {
    int target = -1;
    int targetHealth;
    int damage;
    while (target == -1) {
        std::cout << "Choose target" << std::endl;
        std::cin >> target;
        targetHealth = party[target - 1]->getHealth();
        if (targetHealth == 0) {
            std::cout << "Target is defeated" << std::endl;
            target = -1;
        } else {
            damage = this->getAttack() * (1 - party[target - 1]->getProtection());
            targetHealth -= damage;
            party[target - 1]->setHealth(targetHealth);
        }
    }
    std::cout << this->getName() << " dealt "  << damage << " to " << party[target - 1]->getName() << std::endl;
}

void Knight::ability(std::vector<Hero*>& party) {
    this->setProtection(this->getProtection() + 0.1);
}