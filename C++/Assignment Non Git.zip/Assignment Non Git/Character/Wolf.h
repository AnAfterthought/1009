#ifndef WOLF_H
#define WOLF_H

#include "Hero.h"

class Wolf:public Hero {
    public:
        Wolf(std::string, int, int, double, int, bool);
        void strike(std::vector<Hero*>&);
        void ability(std::vector<Hero*>&);
};

#endif