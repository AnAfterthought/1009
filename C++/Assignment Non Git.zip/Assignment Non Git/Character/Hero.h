#ifndef HERO_H
#define HERO_H

#include <iostream>
#include <vector>
#include <string>

class Hero {
    private:
        std::string name;
        int health;
        int attack;
        double protection;
        int speed;
        int turnMeter;
        bool playerCharacter;
    public:
        Hero(std::string, int, int, double, int, bool);
        virtual ~Hero();
        std::string getName();
        int getHealth();
        void setHealth(int);
        int getAttack();
        void setAttack(int);
        double getProtection();
        void setProtection(double);
        int getSpeed();
        void setSpeed(int);
        int getTurnMeter();
        void setTurnMeter();
        bool isPlayerCharacter();
        void makeDecision(std::vector<Hero*>&);
        virtual void strike(std::vector<Hero*>&);
        //virtual void ability(std::vector<Hero*>&);
};

#endif