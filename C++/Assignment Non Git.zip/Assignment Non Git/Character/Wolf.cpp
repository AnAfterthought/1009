#include "Wolf.h"

Wolf::Wolf(std::string name, int health, int attack, double protection, int speed, bool playerCharacter):Hero(name, health, attack, protection, speed, playerCharacter) {

}

void Wolf::strike(std::vector<Hero*>& party) {
    int target = -1;
    int targetHealth;
    int damage;
    while (target == -1) {
        target = rand() % party.size();
        targetHealth = party[target]->getHealth();
        if (targetHealth == 0) {
            target = -1;
        }
    }
    damage = this->getAttack() * (1 - party[target]->getProtection());
    targetHealth -= damage;
    party[target]->setHealth(targetHealth);
    std::cout << this->getName() << " dealt " << damage << " to " << party[target]->getName() << std::endl;
}

void Wolf::ability(std::vector<Hero*>& party) {
    this->setProtection(this->getProtection() + 0.1);
}