#include "Hero.h"

Hero::Hero(std::string name, int health, int attack, double protection, int speed, bool playerCharacter) {
    this->name = name;
    this->health = health;
    this->attack = attack;
    this->protection = protection;
    this->speed = speed;
    this->turnMeter = 0;
    this->playerCharacter = playerCharacter;
}

Hero::~Hero() {
}

std::string Hero::getName() {
    return this->name;
}

int Hero::getHealth() {
    return this->health;
}

void Hero::setHealth(int health) {
    this->health = health;
    if (this->health <= 0) {
        this->health = 0;
    }
}

int Hero::getAttack() {
    return this->attack;
}

void Hero::setAttack(int attack) {
    this->attack = attack;
}

double Hero::getProtection() {
    return this->protection;
}

void Hero::setProtection(double protection) {
    this->protection = protection;
}

int Hero::getSpeed() {
    return this->speed;
}

void Hero::setSpeed(int speed) {
    this->speed = speed;
}

int Hero::getTurnMeter() {
    return this->turnMeter;
}

void Hero::setTurnMeter() {
    if (this->health > 0) {
        this->turnMeter += this->speed;
    }
}

bool Hero::isPlayerCharacter() {
    return this->playerCharacter;
}

void Hero::makeDecision(std::vector<Hero*>& party) {
    int choice;
    if (this->playerCharacter) {
        std::cout << "1. Attack" << std::endl;
        std::cout << "2. Ability" << std::endl;
        std::cin >> choice;
    } else {
        choice = rand() % 2;
    }
    if (choice == 0 || choice == 1) {
        this->strike(party);
    } /*else if (choice == 2) {
        this->ability(party);
    }*/
    this->turnMeter -= 100;
}

void Hero::strike(std::vector<Hero*>& party) {

}

/*void Hero::ability(std::vector<Hero*>& party) {

}*/