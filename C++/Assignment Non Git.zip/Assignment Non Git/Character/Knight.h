#ifndef KNIGHT_H
#define KNIGHT_H

#include "Hero.h"

class Knight:public Hero {
    public:
        Knight(std::string, int, int, double, int, bool);
        void strike(std::vector<Hero*>&);
        void ability(std::vector<Hero*>&);
};

#endif